import { useState, useEffect, useRef, useCallback } from 'react';

/* ══════════════════════════════════════════
   POGOPOP — COMPLETE KIDS GAME
   16:9 | No Music | Tap to Jump | Ages 2+
   ══════════════════════════════════════════ */

// ── CONSTANTS ──
const GW = 1280, GH = 720;
const GRAVITY = 0.55, JUMP_VEL = -11.5;
const GROUND_Y = 560;
const PLAYER_W = 50, PLAYER_H = 55;
const BASE_SPEED = 3.5;

// ── THEMES (every 3 levels) ──
const THEMES = [
  { name:'Meadow',    sky1:'#87CEEB',sky2:'#E0F7FA',ground:'#4CAF50',groundD:'#388E3C',hill:'#66BB6A',hillD:'#43A047',obs:'#795548',obsD:'#5D4037',plat:'#8BC34A',accent:'#FFEB3B' },
  { name:'Garden',    sky1:'#F8BBD0',sky2:'#FCE4EC',ground:'#66BB6A',groundD:'#43A047',hill:'#81C784',hillD:'#4CAF50',obs:'#6D4C41',obsD:'#4E342E',plat:'#AED581',accent:'#FF80AB' },
  { name:'Candy',     sky1:'#E1BEE7',sky2:'#F3E5F5',ground:'#CE93D8',groundD:'#AB47BC',hill:'#BA68C8',hillD:'#9C27B0',obs:'#F48FB1',obsD:'#E91E63',plat:'#F8BBD0',accent:'#FFD54F' },
  { name:'Beach',     sky1:'#4FC3F7',sky2:'#B3E5FC',ground:'#FFD54F',groundD:'#FFC107',hill:'#FFE082',hillD:'#FFD54F',obs:'#8D6E63',obsD:'#6D4C41',plat:'#FFCC80',accent:'#FF7043' },
  { name:'Snow',      sky1:'#B3E5FC',sky2:'#E1F5FE',ground:'#ECEFF1',groundD:'#CFD8DC',hill:'#E0E0E0',hillD:'#BDBDBD',obs:'#607D8B',obsD:'#455A64',plat:'#B0BEC5',accent:'#4FC3F7' },
  { name:'Night',     sky1:'#1A237E',sky2:'#283593',ground:'#1B5E20',groundD:'#0D3B0F',hill:'#2E7D32',hillD:'#1B5E20',obs:'#37474F',obsD:'#263238',plat:'#388E3C',accent:'#FFD740' },
];

// ── SOUND ──
let _ac: AudioContext | null = null;
function ac() { if (!_ac) _ac = new (window.AudioContext || (window as any).webkitAudioContext)(); return _ac; }
function tone(f: number, d = 0.12, t: OscillatorType = 'sine', v = 0.12) {
  try { const c = ac(), o = c.createOscillator(), g = c.createGain(); o.type = t; o.frequency.value = f; g.gain.setValueAtTime(v, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + d); o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + d); } catch {}
}
const sfx = {
  jump: () => { tone(500, 0.08, 'triangle'); setTimeout(() => tone(700, 0.08, 'triangle'), 50); },
  collect: () => { tone(880, 0.08); setTimeout(() => tone(1200, 0.1), 60); },
  crash: () => { tone(120, 0.35, 'sawtooth', 0.18); },
  levelUp: () => { [523,659,784,1047].forEach((f,i) => setTimeout(() => tone(f, 0.2, 'sine', 0.1), i * 120)); },
  click: () => tone(660, 0.04, 'sine', 0.08),
  spring: () => { tone(400, 0.06, 'triangle'); setTimeout(() => tone(800, 0.1, 'triangle'), 50); },
  star: () => { tone(1000, 0.05); setTimeout(() => tone(1400, 0.08), 40); setTimeout(() => tone(1800, 0.1), 80); },
};

// ── LEVEL GENERATION ──
interface LvlObj { x: number; type: 'star'|'letter'|'rock'|'gap'|'spring'|'mushroom'|'flag'; y: number; w: number; h: number; letter?: string; collected?: boolean; }
interface Level { objs: LvlObj[]; len: number; theme: number; }

function genLevel(n: number): Level {
  const theme = (Math.floor((n - 1) / 3)) % THEMES.length;
  const diff = Math.min(n * 0.08, 0.7);
  const len = 4000 + n * 600;
  const objs: LvlObj[] = [];
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  for (let x = 400; x < len - 200; ) {
    const r = Math.random();
    if (r < 0.25 + diff * 0.1) {
      // Star
      objs.push({ x, type: 'star', y: GROUND_Y - 80 - Math.random() * 100, w: 30, h: 30 });
      x += 120 + Math.random() * 100;
    } else if (r < 0.4 && diff > 0.15) {
      // Letter
      objs.push({ x, type: 'letter', y: GROUND_Y - 90 - Math.random() * 80, w: 36, h: 36, letter: letters[Math.floor(Math.random() * 26)] });
      x += 140 + Math.random() * 100;
    } else if (r < 0.55 + diff * 0.15) {
      // Rock obstacle
      const rw = 35 + Math.random() * 20;
      const rh = 30 + Math.random() * 25 + diff * 20;
      objs.push({ x, type: 'rock', y: GROUND_Y - rh, w: rw, h: rh });
      x += rw + 150 + Math.random() * 100;
    } else if (r < 0.7 + diff * 0.1 && diff > 0.25) {
      // Gap
      const gw = 60 + diff * 80;
      objs.push({ x, type: 'gap', y: GROUND_Y, w: gw, h: 40 });
      x += gw + 180 + Math.random() * 80;
    } else if (r < 0.82 && diff > 0.2) {
      // Mushroom (bouncy)
      objs.push({ x, type: 'mushroom', y: GROUND_Y - 28, w: 40, h: 28 });
      objs.push({ x, type: 'star', y: GROUND_Y - 200, w: 30, h: 30 });
      x += 200;
    } else if (r < 0.9) {
      // Spring
      objs.push({ x, type: 'spring', y: GROUND_Y - 20, w: 30, h: 20 });
      objs.push({ x: x + 10, type: 'star', y: GROUND_Y - 250, w: 30, h: 30 });
      x += 200;
    } else {
      // Letter cluster
      for (let li = 0; li < 3; li++) {
        objs.push({ x: x + li * 45, type: 'letter', y: GROUND_Y - 100 - Math.random() * 60, w: 36, h: 36, letter: letters[Math.floor(Math.random() * 26)] });
      }
      x += 200;
    }
  }

  // Flag at end
  objs.push({ x: len - 100, type: 'flag', y: GROUND_Y - 100, w: 40, h: 100 });

  return { objs, len, theme };
}

// ── SAVE/LOAD ──
function getProgress(): { maxLevel: number; stars: Record<number, number> } {
  try {
    const d = localStorage.getItem('pogopop_save');
    if (d) return JSON.parse(d);
  } catch {}
  return { maxLevel: 1, stars: {} };
}
function saveProgress(maxLevel: number, stars: Record<number, number>) {
  try { localStorage.setItem('pogopop_save', JSON.stringify({ maxLevel, stars })); } catch {}
}

// ── DRAWING HELPERS ──
function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawPogo(ctx: CanvasRenderingContext2D, x: number, y: number, frame: number, vy: number, onGround: boolean, scale = 1) {
  const s = scale;
  const bob = onGround ? Math.sin(frame * 0.18) * 2 * s : 0;
  const squash = !onGround ? (vy < 0 ? 0.85 : 1.15) : 1;
  const stretch = !onGround ? (vy < 0 ? 1.15 : 0.85) : 1;
  const cy = y - bob;

  ctx.save();
  ctx.translate(x, cy);
  ctx.scale(squatch(squash), squatch(stretch));

  // Shadow
  if (onGround) {
    ctx.fillStyle = 'rgba(0,0,0,0.12)';
    ctx.beginPath(); ctx.ellipse(0, 28 * s, 22 * s, 5 * s, 0, 0, Math.PI * 2); ctx.fill();
  }

  // Legs
  const legA = onGround ? Math.sin(frame * 0.22) * 0.5 : 0.2;
  ctx.strokeStyle = '#FF8F00'; ctx.lineWidth = 5 * s; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(-8 * s, 16 * s); ctx.lineTo(-8 * s + Math.sin(legA) * 8 * s, 28 * s); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(8 * s, 16 * s); ctx.lineTo(8 * s - Math.sin(legA) * 8 * s, 28 * s); ctx.stroke();

  // Shoes
  ctx.fillStyle = '#E53935';
  ctx.beginPath(); ctx.ellipse(-8 * s + Math.sin(legA) * 8 * s, 30 * s, 6 * s, 3.5 * s, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(8 * s - Math.sin(legA) * 8 * s, 30 * s, 6 * s, 3.5 * s, 0, 0, Math.PI * 2); ctx.fill();

  // Body
  const bg = ctx.createRadialGradient(0, -2 * s, 2 * s, 0, 0, 24 * s);
  bg.addColorStop(0, '#FFCA28'); bg.addColorStop(1, '#FFB300');
  ctx.fillStyle = bg;
  ctx.beginPath(); ctx.ellipse(0, 0, 24 * s, 22 * s, 0, 0, Math.PI * 2); ctx.fill();

  // Belly
  ctx.fillStyle = '#FFF9C4';
  ctx.beginPath(); ctx.ellipse(0, 5 * s, 14 * s, 12 * s, 0, 0, Math.PI * 2); ctx.fill();

  // Arms
  const armA = onGround ? Math.sin(frame * 0.22 + 1) * 0.4 : -0.3;
  ctx.strokeStyle = '#FFB300'; ctx.lineWidth = 5 * s;
  ctx.beginPath(); ctx.moveTo(-22 * s, -2 * s); ctx.lineTo(-28 * s, 8 * s + Math.sin(armA) * 4 * s); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(22 * s, -2 * s); ctx.lineTo(28 * s, 8 * s - Math.sin(armA) * 4 * s); ctx.stroke();

  // Hands
  ctx.fillStyle = '#FF8F00';
  ctx.beginPath(); ctx.arc(-28 * s, 10 * s + Math.sin(armA) * 4 * s, 4 * s, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(28 * s, 10 * s - Math.sin(armA) * 4 * s, 4 * s, 0, Math.PI * 2); ctx.fill();

  // Eyes
  ctx.fillStyle = 'white';
  ctx.beginPath(); ctx.ellipse(-9 * s, -8 * s, 8 * s, 9 * s, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(9 * s, -8 * s, 8 * s, 9 * s, 0, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#1A1A2E';
  ctx.beginPath(); ctx.arc(-7 * s, -7 * s, 4 * s, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(11 * s, -7 * s, 4 * s, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = 'white';
  ctx.beginPath(); ctx.arc(-5.5 * s, -9 * s, 1.8 * s, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(12.5 * s, -9 * s, 1.8 * s, 0, Math.PI * 2); ctx.fill();

  // Blush
  ctx.fillStyle = 'rgba(255,138,128,0.35)';
  ctx.beginPath(); ctx.ellipse(-17 * s, 0, 5 * s, 3 * s, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.ellipse(17 * s, 0, 5 * s, 3 * s, 0, 0, Math.PI * 2); ctx.fill();

  // Mouth
  ctx.strokeStyle = '#5D4037'; ctx.lineWidth = 2 * s; ctx.lineCap = 'round';
  ctx.beginPath(); ctx.arc(1 * s, -1 * s, 6 * s, 0.2, Math.PI - 0.2); ctx.stroke();

  // Hat
  ctx.fillStyle = '#E53935';
  ctx.beginPath(); ctx.ellipse(0, -20 * s, 22 * s, 5 * s, 0, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(0, -25 * s, 13 * s, Math.PI, 0); ctx.fill();
  ctx.fillStyle = '#FFEB3B';
  ctx.beginPath(); ctx.arc(0, -36 * s, 4 * s, 0, Math.PI * 2); ctx.fill();

  ctx.restore();
}

function squatch(v: number) { return Math.max(0.5, Math.min(1.5, v)); }

function drawStar(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, rot: number, color: string) {
  ctx.save(); ctx.translate(x, y); ctx.rotate(rot);
  ctx.fillStyle = color;
  ctx.beginPath();
  for (let i = 0; i < 5; i++) {
    const a = (i * 4 * Math.PI) / 5 - Math.PI / 2;
    const method = i === 0 ? 'moveTo' : 'lineTo';
    ctx[method](Math.cos(a) * r, Math.sin(a) * r);
  }
  ctx.closePath(); ctx.fill();
  ctx.restore();
}

// ── GAME SCREEN ──
function GamePlay({ level, onWin, onLose }: { level: number; onWin: (stars: number) => void; onLose: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<any>(null);

  const initLevel = useCallback(() => {
    const lvl = genLevel(level);
    return {
      lvl,
      px: 120, py: GROUND_Y - PLAYER_H, pvx: 0, pvy: 0,
      onGround: true, jumping: false,
      camX: 0, frame: 0,
      starsCollected: 0, totalStars: lvl.objs.filter(o => o.type === 'star').length,
      lettersCollected: [] as string[],
      alive: true, won: false,
      particles: [] as { x: number; y: number; vx: number; vy: number; life: number; color: string; size: number }[],
      jumpPressed: false,
      introTimer: 60,
      groundY: GROUND_Y,
      speed: BASE_SPEED + level * 0.15,
    };
  }, [level]);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const st = initLevel();
    stateRef.current = st;

    let animId = 0;

    // Controls
    const doJump = () => {
      if (st.introTimer > 0) return;
      if (st.onGround && st.alive && !st.won) {
        st.pvy = JUMP_VEL;
        st.onGround = false;
        st.jumping = true;
        sfx.jump();
      }
    };
    const onKeyDown = (e: KeyboardEvent) => { if (e.key === ' ' || e.key === 'ArrowUp' || e.key === 'w') { e.preventDefault(); doJump(); } };
    const onMouseDown = (e: MouseEvent) => { e.preventDefault(); doJump(); };
    const onTouchStart = (e: TouchEvent) => { e.preventDefault(); doJump(); };

    window.addEventListener('keydown', onKeyDown);
    canvas.addEventListener('mousedown', onMouseDown);
    canvas.addEventListener('touchstart', onTouchStart, { passive: false });

    function addParticle(x: number, y: number, color: string, n: number) {
      for (let i = 0; i < n; i++) {
        const a = Math.random() * Math.PI * 2;
        const sp = 1.5 + Math.random() * 3.5;
        st.particles.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - 2, life: 1, color, size: 2 + Math.random() * 4 });
      }
    }

    function gameLoop() {
      const w = GW, h = GH;
      st.frame++;

      // Intro countdown
      if (st.introTimer > 0) {
        st.introTimer--;
        // Still draw
        drawFrame(ctx, w, h);
        animId = requestAnimationFrame(gameLoop);
        return;
      }

      if (!st.alive || st.won) {
        drawFrame(ctx, w, h);
        return;
      }

      // Move player forward
      st.px += st.speed;
      st.camX = st.px - 200;

      // Gravity
      st.pvy += GRAVITY;
      st.py += st.pvy;

      // Ground collision (check gaps)
      let onGap = false;
      for (const obj of st.lvl.objs) {
        if (obj.type === 'gap') {
          if (st.px + PLAYER_W / 2 > obj.x && st.px - PLAYER_W / 2 < obj.x + obj.w) {
            onGap = true;
          }
        }
      }

      if (!onGap && st.py + PLAYER_H >= GROUND_Y) {
        st.py = GROUND_Y - PLAYER_H;
        st.pvy = 0;
        st.onGround = true;
        st.jumping = false;
      }

      // Fall into gap
      if (onGap && st.py > GH + 50) {
        st.alive = false;
        sfx.crash();
        setTimeout(() => onLose(), 800);
        drawFrame(ctx, w, h);
        return;
      }

      // Object collision
      for (const obj of st.lvl.objs) {
        if (obj.collected) continue;
        const ox = obj.x, oy = obj.y, ow = obj.w, oh = obj.h;
        const px = st.px, py = st.py;

        if (obj.type === 'star') {
          if (px + PLAYER_W / 2 > ox - ow / 2 && px - PLAYER_W / 2 < ox + ow / 2 &&
              py + PLAYER_H > oy - oh / 2 && py < oy + oh / 2) {
            obj.collected = true;
            st.starsCollected++;
            sfx.star();
            addParticle(ox - st.camX, oy, '#FFD740', 8);
          }
        } else if (obj.type === 'letter') {
          if (px + PLAYER_W / 2 > ox - ow / 2 && px - PLAYER_W / 2 < ox + ow / 2 &&
              py + PLAYER_H > oy - oh / 2 && py < oy + oh / 2) {
            obj.collected = true;
            st.lettersCollected.push(obj.letter!);
            sfx.collect();
            addParticle(ox - st.camX, oy, '#E040FB', 6);
          }
        } else if (obj.type === 'rock' || obj.type === 'mushroom') {
          if (px + PLAYER_W / 2 > ox - ow / 2 + 5 && px - PLAYER_W / 2 < ox + ow / 2 - 5 &&
              py + PLAYER_H > oy && py + PLAYER_H < oy + oh * 0.7 && st.pvy >= 0) {
            if (obj.type === 'mushroom') {
              st.pvy = JUMP_VEL * 1.5;
              st.onGround = false;
              sfx.spring();
              addParticle(px - st.camX, py + PLAYER_H, '#4CAF50', 6);
            } else {
              st.alive = false;
              sfx.crash();
              addParticle(px - st.camX, py + PLAYER_H / 2, '#FF5722', 12);
              setTimeout(() => onLose(), 800);
            }
          } else if (px + PLAYER_W / 2 > ox - ow / 2 + 8 && px - PLAYER_W / 2 < ox + ow / 2 - 8 &&
                     py + PLAYER_H > oy + 5 && py < oy + oh) {
            st.alive = false;
            sfx.crash();
            addParticle(px - st.camX, py + PLAYER_H / 2, '#FF5722', 12);
            setTimeout(() => onLose(), 800);
          }
        } else if (obj.type === 'spring') {
          if (px + PLAYER_W / 2 > ox - ow / 2 && px - PLAYER_W / 2 < ox + ow / 2 &&
              py + PLAYER_H > oy && py + PLAYER_H < oy + oh + 10 && st.pvy >= 0) {
            st.pvy = JUMP_VEL * 2;
            st.onGround = false;
            sfx.spring();
            addParticle(px - st.camX, oy, '#00BCD4', 8);
          }
        } else if (obj.type === 'flag') {
          if (px + PLAYER_W / 2 > ox - ow / 2 && px - PLAYER_W / 2 < ox + ow / 2) {
            obj.collected = true;
            st.won = true;
            sfx.levelUp();
            const stars = st.starsCollected >= st.totalStars ? 3 : st.starsCollected >= st.totalStars * 0.5 ? 2 : 1;
            setTimeout(() => onWin(stars), 1200);
          }
        }
      }

      // Update particles
      for (const p of st.particles) {
        p.x += p.vx; p.y += p.vy; p.vy += 0.08; p.life -= 0.025;
      }
      st.particles = st.particles.filter(p => p.life > 0);

      drawFrame(ctx, w, h);
      animId = requestAnimationFrame(gameLoop);
    }

    function drawFrame(ctx: CanvasRenderingContext2D, w: number, h: number) {
      const theme = THEMES[st.lvl.theme];
      ctx.clearRect(0, 0, w, h);

      // Sky
      const skyG = ctx.createLinearGradient(0, 0, 0, h * 0.8);
      skyG.addColorStop(0, theme.sky1); skyG.addColorStop(1, theme.sky2);
      ctx.fillStyle = skyG; ctx.fillRect(0, 0, w, h);

      // Clouds (parallax)
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      for (let i = 0; i < 6; i++) {
        const cx = ((i * 250 - st.camX * 0.1) % (w + 200)) - 100;
        const cy = 60 + i * 40;
        ctx.beginPath(); ctx.ellipse(cx, cy, 50 + i * 5, 20, 0, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(cx + 30, cy - 10, 35, 18, 0, 0, Math.PI * 2); ctx.fill();
      }

      // Hills (parallax)
      ctx.fillStyle = theme.hill;
      for (let i = 0; i < 8; i++) {
        const hx = ((i * 200 - st.camX * 0.2) % (w + 400)) - 200;
        ctx.beginPath();
        ctx.moveTo(hx - 120, GROUND_Y + 20);
        ctx.quadraticCurveTo(hx, GROUND_Y - 80 - i * 10, hx + 120, GROUND_Y + 20);
        ctx.fill();
      }
      ctx.fillStyle = theme.hillD;
      for (let i = 0; i < 5; i++) {
        const hx = ((i * 280 + 100 - st.camX * 0.3) % (w + 400)) - 200;
        ctx.beginPath();
        ctx.moveTo(hx - 100, GROUND_Y + 20);
        ctx.quadraticCurveTo(hx, GROUND_Y - 50 - i * 8, hx + 100, GROUND_Y + 20);
        ctx.fill();
      }

      // Ground
      const grdG = ctx.createLinearGradient(0, GROUND_Y, 0, h);
      grdG.addColorStop(0, theme.ground); grdG.addColorStop(1, theme.groundD);
      ctx.fillStyle = grdG; ctx.fillRect(0, GROUND_Y, w, h - GROUND_Y);

      // Ground line
      ctx.strokeStyle = theme.groundD; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, GROUND_Y); ctx.lineTo(w, GROUND_Y); ctx.stroke();

      // Grass tufts
      ctx.fillStyle = theme.hill;
      for (let i = 0; i < 30; i++) {
        const gx = ((i * 50 - st.camX) % (w + 100)) - 50;
        ctx.beginPath();
        ctx.moveTo(gx, GROUND_Y); ctx.lineTo(gx + 4, GROUND_Y - 8); ctx.lineTo(gx + 8, GROUND_Y);
        ctx.fill();
      }

      // Draw objects
      const camX = st.camX;
      for (const obj of st.lvl.objs) {
        const sx = obj.x - camX;
        if (sx < -100 || sx > w + 100) continue;
        if (obj.collected && obj.type !== 'flag') continue;

        if (obj.type === 'star' && !obj.collected) {
          const rot = st.frame * 0.05;
          const bobY = Math.sin(st.frame * 0.06 + obj.x * 0.01) * 5;
          drawStar(ctx, sx, obj.y + bobY, 16, rot, '#FFD740');
          ctx.fillStyle = '#FFF9C4';
          ctx.beginPath(); ctx.arc(sx - 3, obj.y + bobY - 3, 4, 0, Math.PI * 2); ctx.fill();
        }
        else if (obj.type === 'letter' && !obj.collected) {
          const bobY = Math.sin(st.frame * 0.05 + obj.x * 0.01) * 6;
          ctx.fillStyle = '#7C4DFF';
          ctx.beginPath(); ctx.arc(sx, obj.y + bobY, 20, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#B388FF';
          ctx.beginPath(); ctx.arc(sx - 4, obj.y + bobY - 4, 8, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = 'white';
          ctx.font = 'bold 22px Fredoka, sans-serif';
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText(obj.letter!, sx, obj.y + bobY + 1);
        }
        else if (obj.type === 'rock') {
          const rg = ctx.createLinearGradient(sx - obj.w / 2, obj.y, sx + obj.w / 2, obj.y + obj.h);
          rg.addColorStop(0, theme.obs); rg.addColorStop(1, theme.obsD);
          ctx.fillStyle = rg;
          rr(ctx, sx - obj.w / 2, obj.y, obj.w, obj.h, 6);
          ctx.fill();
          // Face
          ctx.fillStyle = 'rgba(255,255,255,0.5)';
          ctx.beginPath(); ctx.arc(sx - 5, obj.y + obj.h * 0.35, 4, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(sx + 5, obj.y + obj.h * 0.35, 4, 0, Math.PI * 2); ctx.fill();
          ctx.fillStyle = '#333';
          ctx.beginPath(); ctx.arc(sx - 5, obj.y + obj.h * 0.35, 2, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(sx + 5, obj.y + obj.h * 0.35, 2, 0, Math.PI * 2); ctx.fill();
          // Angry brows
          ctx.strokeStyle = '#333'; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.moveTo(sx - 8, obj.y + obj.h * 0.2); ctx.lineTo(sx - 2, obj.y + obj.h * 0.28); ctx.stroke();
          ctx.beginPath(); ctx.moveTo(sx + 8, obj.y + obj.h * 0.2); ctx.lineTo(sx + 2, obj.y + obj.h * 0.28); ctx.stroke();
        }
        else if (obj.type === 'gap') {
          // Dark pit
          ctx.fillStyle = '#1A1A2E';
          ctx.fillRect(sx, GROUND_Y, obj.w, h - GROUND_Y);
          // Warning stripes
          ctx.fillStyle = 'rgba(255,193,7,0.3)';
          for (let si = 0; si < obj.w; si += 16) {
            ctx.fillRect(sx + si, GROUND_Y, 8, 20);
          }
        }
        else if (obj.type === 'mushroom') {
          // Stem
          ctx.fillStyle = '#F5F5F5';
          ctx.fillRect(sx - 6, obj.y + 10, 12, 18);
          // Cap
          ctx.fillStyle = '#F44336';
          ctx.beginPath(); ctx.ellipse(sx, obj.y + 8, 22, 14, 0, Math.PI, 0); ctx.fill();
          // Dots
          ctx.fillStyle = 'white';
          ctx.beginPath(); ctx.arc(sx - 8, obj.y + 2, 4, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(sx + 8, obj.y, 3, 0, Math.PI * 2); ctx.fill();
        }
        else if (obj.type === 'spring') {
          ctx.fillStyle = '#00BCD4';
          rr(ctx, sx - 15, obj.y, 30, 12, 3); ctx.fill();
          // Coil
          ctx.strokeStyle = '#0097A7'; ctx.lineWidth = 3;
          ctx.beginPath();
          for (let si = 0; si < 4; si++) {
            ctx.moveTo(sx - 10 + si * 7, obj.y + 6);
            ctx.lineTo(sx - 10 + si * 7, obj.y - 8);
          }
          ctx.stroke();
          ctx.fillStyle = '#FF5722';
          rr(ctx, sx - 18, obj.y - 14, 36, 8, 4); ctx.fill();
        }
        else if (obj.type === 'flag') {
          // Pole
          ctx.fillStyle = '#795548'; ctx.fillRect(sx - 3, obj.y, 6, obj.h);
          // Flag
          const wave = Math.sin(st.frame * 0.08) * 3;
          ctx.fillStyle = '#4CAF50';
          ctx.beginPath();
          ctx.moveTo(sx + 3, obj.y);
          ctx.lineTo(sx + 50 + wave, obj.y + 15);
          ctx.lineTo(sx + 3, obj.y + 30);
          ctx.closePath(); ctx.fill();
          // Star on flag
          drawStar(ctx, sx + 25 + wave * 0.5, obj.y + 15, 8, 0, '#FFD740');
        }
      }

      // Draw player
      const playerScreenX = st.px - camX;
      const playerScreenY = st.py;
      if (st.alive) {
        drawPogo(ctx, playerScreenX, playerScreenY + PLAYER_H / 2, st.frame, st.pvy, st.onGround);
      } else {
        // Death animation - spinning
        ctx.save();
        ctx.translate(playerScreenX, playerScreenY + PLAYER_H / 2);
        ctx.rotate(st.frame * 0.15);
        ctx.globalAlpha = 0.6;
        drawPogo(ctx, 0, 0, st.frame, st.pvy, false, 0.8);
        ctx.restore();
      }

      // Particles
      for (const p of st.particles) {
        const alpha = Math.max(0, p.life);
        ctx.globalAlpha = alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;

      // HUD
      // Stars
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      rr(ctx, 20, 20, 180, 48, 14); ctx.fill();
      drawStar(ctx, 52, 44, 14, 0, '#FFD740');
      ctx.fillStyle = 'white'; ctx.font = 'bold 24px Fredoka, sans-serif';
      ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(`${st.starsCollected} / ${st.totalStars}`, 72, 45);

      // Letters
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      rr(ctx, 20, 78, 180, 40, 14); ctx.fill();
      ctx.fillStyle = '#B388FF'; ctx.font = 'bold 18px Fredoka';
      ctx.fillText(`ABC: ${st.lettersCollected.join('')}`, 36, 100);

      // Level
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      rr(ctx, w - 170, 20, 150, 48, 14); ctx.fill();
      ctx.fillStyle = 'white'; ctx.font = 'bold 22px Fredoka';
      ctx.textAlign = 'right';
      ctx.fillText(`Level ${level}`, w - 36, 46);
      ctx.textAlign = 'left';

      // Progress bar
      const progress = Math.min(st.px / st.lvl.len, 1);
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      rr(ctx, w / 2 - 150, 25, 300, 16, 8); ctx.fill();
      ctx.fillStyle = '#4CAF50';
      rr(ctx, w / 2 - 150, 25, 300 * progress, 16, 8); ctx.fill();
      // Pogo icon on progress
      ctx.fillStyle = '#FFB300';
      ctx.beginPath(); ctx.arc(w / 2 - 150 + 300 * progress, 33, 8, 0, Math.PI * 2); ctx.fill();

      // Intro countdown
      if (st.introTimer > 0) {
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.fillRect(0, 0, w, h);
        const countNum = Math.ceil(st.introTimer / 20);
        ctx.fillStyle = 'white';
        ctx.font = 'bold 120px Lilita One, Fredoka, sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        if (countNum > 0) {
          const scale = 1 + (st.introTimer % 20) / 20 * 0.3;
          ctx.save(); ctx.translate(w / 2, h / 2); ctx.scale(scale, scale);
          ctx.fillText(countNum.toString(), 0, 0);
          ctx.restore();
        }
        ctx.font = 'bold 36px Fredoka';
        ctx.fillStyle = '#FFD740';
        ctx.fillText('GET READY!', w / 2, h / 2 - 100);
        ctx.textAlign = 'left';
      }

      // Win overlay
      if (st.won) {
        ctx.fillStyle = 'rgba(0,0,0,0.4)';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#FFD740';
        ctx.font = 'bold 64px Lilita One, Fredoka';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('LEVEL COMPLETE!', w / 2, h / 2 - 30);
        // Stars
        const winStars = st.starsCollected >= st.totalStars ? 3 : st.starsCollected >= st.totalStars * 0.5 ? 2 : 1;
        for (let i = 0; i < 3; i++) {
          drawStar(ctx, w / 2 - 60 + i * 60, h / 2 + 40, 22, 0, i < winStars ? '#FFD740' : '#555');
        }
        ctx.textAlign = 'left';
      }
    }

    animId = requestAnimationFrame(gameLoop);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', onKeyDown);
      canvas.removeEventListener('mousedown', onMouseDown);
      canvas.removeEventListener('touchstart', onTouchStart);
    };
  }, [level, onWin, onLose, initLevel]);

  return (
    <div className="w-full h-screen flex items-center justify-center bg-black">
      <canvas ref={canvasRef} width={GW} height={GH}
        style={{ maxWidth: '100vw', maxHeight: '100vh', width: 'auto', height: 'auto', aspectRatio: '16/9', imageRendering: 'auto' }}
      />
    </div>
  );
}

// ── LEVEL SELECT ──
function LevelSelect({ maxLevel, stars, onSelect, onBack }: { maxLevel: number; stars: Record<number, number>; onSelect: (l: number) => void; onBack: () => void }) {
  return (
    <div className="w-full h-screen flex items-center justify-center bg-gradient-to-b from-indigo-600 to-purple-800 overflow-auto p-4">
      <div className="w-full max-w-2xl">
        <div className="flex items-center justify-between mb-6">
          <button onClick={onBack} className="bg-white/20 text-white px-5 py-2 rounded-xl font-bold text-lg hover:bg-white/30 transition-colors">← Back</button>
          <h2 className="font-heading text-3xl font-bold text-white" style={{ textShadow: '2px 2px 0 rgba(0,0,0,0.3)' }}>Choose Level</h2>
          <div className="w-20" />
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
          {Array.from({ length: Math.max(maxLevel + 2, 10) }, (_, i) => {
            const l = i + 1;
            const unlocked = l <= maxLevel;
            const s = stars[l] || 0;
            const theme = THEMES[(Math.floor((l - 1) / 3)) % THEMES.length];
            return (
              <button key={l} onClick={() => unlocked ? (sfx.click(), onSelect(l)) : null}
                className={`relative aspect-square rounded-2xl font-bold text-2xl flex flex-col items-center justify-center transition-all
                  ${unlocked ? 'hover:scale-105 active:scale-95 shadow-lg' : 'opacity-40 cursor-not-allowed'}
                `}
                style={{ backgroundColor: unlocked ? theme.ground : '#555', color: 'white' }}
              >
                <span className="font-heading">{l}</span>
                {s > 0 && (
                  <div className="flex gap-0.5 mt-1">
                    {[1,2,3].map(si => (
                      <span key={si} className="text-xs">{si <= s ? '⭐' : '☆'}</span>
                    ))}
                  </div>
                )}
                {!unlocked && <span className="text-xl">🔒</span>}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── WIN SCREEN ──
function WinScreen({ level, stars, onNext, onMenu }: { level: number; stars: number; onNext: () => void; onMenu: () => void }) {
  return (
    <div className="w-full h-screen flex items-center justify-center bg-gradient-to-b from-green-500 to-emerald-700 p-6">
      <div className="text-center anim-bounce-in">
        <div className="text-7xl mb-4">🎉</div>
        <h2 className="font-heading text-5xl sm:text-6xl font-bold text-white mb-2" style={{ textShadow: '3px 3px 0 rgba(0,0,0,0.2)' }}>Level {level}</h2>
        <p className="text-3xl text-yellow-300 font-bold mb-6">COMPLETE!</p>
        <div className="flex justify-center gap-3 mb-8">
          {[1,2,3].map(i => (
            <span key={i} className={`text-5xl ${i <= stars ? 'anim-bounce-in' : 'opacity-30'}`} style={{ animationDelay: `${i * 0.2}s` }}>
              {i <= stars ? '⭐' : '☆'}
            </span>
          ))}
        </div>
        <div className="flex gap-4 justify-center flex-wrap">
          <button onClick={() => { sfx.click(); onNext(); }} className="bg-gradient-to-r from-green-400 to-emerald-500 text-white px-10 py-5 rounded-2xl font-bold text-2xl hover:scale-105 active:scale-95 transition-transform shadow-xl">
            Next Level →
          </button>
          <button onClick={() => { sfx.click(); onMenu(); }} className="bg-white/20 text-white px-8 py-5 rounded-2xl font-bold text-xl hover:bg-white/30 transition-colors">
            🏠 Menu
          </button>
        </div>
      </div>
    </div>
  );
}

// ── LOSE SCREEN ──
function LoseScreen({ level: _level, onRetry, onMenu }: { level: number; onRetry: () => void; onMenu: () => void }) {
  return (
    <div className="w-full h-screen flex items-center justify-center bg-gradient-to-b from-red-500 to-orange-700 p-6">
      <div className="text-center anim-bounce-in">
        <div className="text-7xl mb-4">💥</div>
        <h2 className="font-heading text-5xl font-bold text-white mb-2" style={{ textShadow: '3px 3px 0 rgba(0,0,0,0.2)' }}>Oops!</h2>
        <p className="text-2xl text-yellow-200 font-bold mb-8">Try again — you got this!</p>
        <div className="flex gap-4 justify-center flex-wrap">
          <button onClick={() => { sfx.click(); onRetry(); }} className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-10 py-5 rounded-2xl font-bold text-2xl hover:scale-105 active:scale-95 transition-transform shadow-xl">
            🔄 Try Again
          </button>
          <button onClick={() => { sfx.click(); onMenu(); }} className="bg-white/20 text-white px-8 py-5 rounded-2xl font-bold text-xl hover:bg-white/30 transition-colors">
            🏠 Menu
          </button>
        </div>
      </div>
    </div>
  );
}

// ── MAIN MENU ──
function MainMenu({ onPlay, onLevels }: { onPlay: () => void; onLevels: () => void }) {
  const [frame, setFrame] = useState(0);
  useEffect(() => { let id: number; const a = () => { setFrame(f => f + 1); id = requestAnimationFrame(a); }; id = requestAnimationFrame(a); return () => cancelAnimationFrame(id); }, []);

  return (
    <div className="w-full h-screen flex flex-col items-center justify-center bg-gradient-to-b from-indigo-600 via-purple-600 to-pink-500 overflow-hidden relative">
      {/* Floating decorations */}
      {Array.from({ length: 12 }, (_, i) => (
        <div key={i} className="absolute text-3xl sm:text-4xl pointer-events-none" style={{
          left: `${(i * 23 + 5) % 90}%`, top: `${(i * 17 + 10) % 80}%`,
          animation: `float-up ${4 + i % 3}s linear infinite`,
          animationDelay: `${i * 0.5}s`, opacity: 0.3,
        }}>
          {['⭐','🌟','💫','✨','🎯','🎈'][i % 6]}
        </div>
      ))}

      <div className="relative z-10 text-center px-6">
        {/* Character */}
        <div className="mb-2">
          <canvas width={200} height={180} ref={el => {
            if (!el) return;
            const c = el.getContext('2d')!;
            c.clearRect(0, 0, 200, 180);
            drawPogo(c, 100, 100, frame, 0, true, 1.8);
          }} className="mx-auto anim-pulse-big" style={{ imageRendering: 'auto' }} />
        </div>

        {/* Title */}
        <h1 className="font-heading text-6xl sm:text-8xl font-bold text-white mb-1" style={{ textShadow: '4px 4px 0 #E65100, 8px 8px 0 rgba(0,0,0,0.2)' }}>
          PogoPop
        </h1>
        <p className="text-xl sm:text-2xl text-yellow-300 font-bold mb-8 anim-wiggle">Bouncy Fun for Everyone!</p>

        {/* Buttons */}
        <div className="flex flex-col gap-4 max-w-xs mx-auto">
          <button onClick={() => { sfx.click(); onPlay(); }}
            className="bg-gradient-to-r from-green-400 to-emerald-500 text-white font-bold text-3xl py-6 px-8 rounded-3xl shadow-2xl shadow-green-500/40 hover:scale-105 active:scale-95 transition-transform"
            style={{ textShadow: '2px 2px 0 rgba(0,0,0,0.2)' }}>
            ▶ PLAY
          </button>
          <button onClick={() => { sfx.click(); onLevels(); }}
            className="bg-gradient-to-r from-purple-400 to-pink-500 text-white font-bold text-2xl py-5 px-8 rounded-3xl shadow-xl shadow-purple-500/30 hover:scale-105 active:scale-95 transition-transform">
            🗺️ LEVELS
          </button>
        </div>

        <p className="text-white/40 text-sm mt-8">Tap or press Space to jump!</p>
      </div>
    </div>
  );
}

// ── APP ──
type Screen = 'menu' | 'levels' | 'game' | 'win' | 'lose';

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [currentLevel, setCurrentLevel] = useState(1);
  const [progress, setProgress] = useState(getProgress());
  const [lastStars, setLastStars] = useState(0);

  const handlePlay = useCallback(() => {
    setCurrentLevel(progress.maxLevel);
    setScreen('game');
  }, [progress.maxLevel]);

  const handleLevelSelect = useCallback((l: number) => {
    setCurrentLevel(l);
    setScreen('game');
  }, []);

  const handleWin = useCallback((stars: number) => {
    const newStars = { ...progress.stars, [currentLevel]: Math.max(progress.stars[currentLevel] || 0, stars) };
    const newMax = Math.max(progress.maxLevel, currentLevel + 1);
    setProgress({ maxLevel: newMax, stars: newStars });
    saveProgress(newMax, newStars);
    setLastStars(stars);
    setScreen('win');
  }, [currentLevel, progress]);

  const handleLose = useCallback(() => { setScreen('lose'); }, []);

  const handleNext = useCallback(() => {
    setCurrentLevel(l => l + 1);
    setScreen('game');
  }, []);

  return (
    <div className="w-full h-screen overflow-hidden bg-black" style={{ fontFamily: "'Fredoka', sans-serif" }}>
      {screen === 'menu' && <MainMenu onPlay={handlePlay} onLevels={() => setScreen('levels')} />}
      {screen === 'levels' && <LevelSelect maxLevel={progress.maxLevel} stars={progress.stars} onSelect={handleLevelSelect} onBack={() => setScreen('menu')} />}
      {screen === 'game' && <GamePlay key={currentLevel} level={currentLevel} onWin={handleWin} onLose={handleLose} />}
      {screen === 'win' && <WinScreen level={currentLevel} stars={lastStars} onNext={handleNext} onMenu={() => setScreen('menu')} />}
      {screen === 'lose' && <LoseScreen level={currentLevel} onRetry={() => setScreen('game')} onMenu={() => setScreen('menu')} />}
    </div>
  );
}
